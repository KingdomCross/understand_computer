the file contains the cluster and the noise


